import alert from './alert.svg';
import negative from './negative.svg';
import positive from './positive.svg';

export default {
	alert,
	negative,
	positive
};