import accesskey from './access-key.svg';
import airplane1 from './airplane-1.svg';
import basketsimple from './basket-simple.svg';
import bell from './bell.svg';
import bin from './bin.svg';
import blockchain from './blockchain.svg';
import bulb63 from './bulb-63.svg';
import camera from './camera.svg';
import carfront from './car-front.svg';
import cardcanceled from './card-canceled.svg';
import cart from './cart.svg';
import cheque3 from './cheque-3.svg';
import comments from './comments.svg';
import configurationtool from './configuration-tool.svg';
import contact from './contact.svg';
import creditcardin from './credit-card-in.svg';
import creditlocked from './credit-locked.svg';
import cutlery from './cutlery.svg';
import design from './design.svg';
import degitalbank from './degital-bank.svg';
import facerecognition from './face-recognition.svg';
import faq from './faq.svg';
import fuel from './fuel.svg';
import globe from './globe.svg';
import handshake from './handshake.svg';
import headphonesmic from './headphones-mic.svg';
import hourglass from './hourglass.svg';
import layout from './layout.svg';
import letter from './letter.svg';
import lock from './lock.svg';
import logic from './logic.svg';
import makeup from './makeup.svg';
import mobilecard from './mobile-card.svg';
import mobilecontact from './mobile-contact.svg';
import moneybag from './money-bag.svg';
import moneyhands from './money-hands.svg';
import openbook from './open-book.svg';
import openingtimes from './opening-times.svg';
import psync from './p-sync.svg';
import password from './password.svg';
import persontoperson from './person-to-person.svg';
import pill42 from './pill-42.svg';
import posmachine from './pos-machine.svg';
import qrcode from './qr-code.svg';
import rate from './rate.svg';
import registerkey from './register-key.svg';
import rounddollar from './round-dollar.svg';
import scanqrcode from './scan-qrcode.svg';
import adjustlimit from './adjust-limit.svg';
import thumbup from './thumb-up.svg';
import timeclock from './time-clock.svg';
import warningsign from './warning-sign.svg';
import webpage from './webpage.svg';
import wheelchairramp from './wheelchair-ramp.svg';
import wifioff from './wifi-off.svg';
import windowdev from './window-dev.svg';

export default {
	'access-key': accesskey,
	'airplane-1': airplane1,
	'basket-simple': basketsimple,
	bell,
	bin,
	blockchain,
	'money-bag': moneybag,
	'bulb-63': bulb63,
	camera,
	'car-front': carfront,
	'card-canceled': cardcanceled,
	cart,
	'cheque-3': cheque3,
	comments,
	'configuration-tool': configurationtool,
	contact,
	'credit-card-in': creditcardin,
	'credit-locked': creditlocked,
	cutlery,
	design,
	'degital-bank': degitalbank,
	'face-recognition': facerecognition,
	faq,
	fuel,
	globe,
	handshake,
	'headphones-mic': headphonesmic,
	hourglass,
	layout,
	letter,
	lock,
	logic,
	makeup,
	'mobile-card': mobilecard,
	'mobile-contact': mobilecontact,
	'money-hands': moneyhands,
	'open-book': openbook,
	'opening-times': openingtimes,
	'p-sync': psync,
	password,
	'person-to-person': persontoperson,
	'pill-42': pill42,
	'pos-machine': posmachine,
	'qr-code': qrcode,
	rate,
	'register-key': registerkey,
	'round-dollar': rounddollar,
	'scan-qrcode': scanqrcode,
	'adjust-limit': adjustlimit,
	'thumb-up': thumbup,
	'time-clock': timeclock,
	'warning-sign': warningsign,
	webpage,
	'wheelchair-ramp': wheelchairramp,
	'wifi-off': wifioff,
	'window-dev': windowdev,
};